if __name__ == '__main__':
    import pandas
    import numpy as np
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    x=df.Intensity.values
    from detect_peaks import detect_peaks
    ind = detect_peaks(x, show=True)
    print(ind)
    # plt.plot(df.Mass,df.Intensity,color='b')
    # plt.bar(MZ,INT,color='r')
    # MZ,INT,d=PeakID(df,2783,1)
    # plt.bar(MZ,INT,color='g')

    # plt.show()

    