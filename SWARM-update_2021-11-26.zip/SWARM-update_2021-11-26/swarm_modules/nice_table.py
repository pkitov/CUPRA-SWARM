import pandas
def nice_table(df,header=True): 
    """ formats df as nicely represented printable tab separated string
    NOTE: don't use on large data like spectra!
    """
    S=''
    if isinstance(df, pandas.DataFrame):
        s=df.to_string(buf=None, columns=None, header=header, index=False, na_rep='NaN', formatters=None, float_format=None, sparsify=None, index_names=True, justify=None)    
        for line in s.split('\n'):
            sp=line.split()
            for f in range(len(sp)):
                S=S+sp[f]+'\t'
            S=S+'\n'
    return S
#################################################################
def test():
    df=pandas.read_table('test_peaks.txt', index_col=False, header=None, names=['Mass','Intensity'])
    nice=nice_table(df)
    print('ugly table\n',df)
    print('nice table\n',nice)
    
if __name__ == '__main__':
    test()

