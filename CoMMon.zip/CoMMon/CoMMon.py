
print('''#   Copyright 2020 Pavel Kitov  pkitov@ualberta.ca
#       
#   This program is free software; you can redistribute and/or modify
#   it under the terms of the GNU General Public License as published 
#   by the Free Software Foundation.
#      
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   This version runs on Python 3.6 or newer
#   Python modules required:
#   Numpy, Scipy, Pandas, Matplotlib.
#   Graphical interface is PyQt5
#   You may obtain all in one package 'Anaconda ver.5.0.0' or newer 
#   from  http://continuum.io/
#   ''')
import os
import time
import sys
from PyQt5.Qt import QApplication, QClipboard
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.uic import loadUiType
import zlib
import sqlite3
import functools
from scipy.signal import savgol_filter as sg
from scipy.signal import resample as rs
import pandas
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import rc
from datetime import datetime
from math import sqrt
# import CoMMon_modules as swrm
try:
    from StringIO import StringIO  # for Python 2.7
    import cPickle
except ImportError:
    from io import StringIO  # for Python 3.x
    import pickle as cPickle
if not os.path.exists('results'):
    os.mkdir('results')

def center_of_gravity(spectrum,min,max,charge):
    """This function calculate centroid of the area in spectrum limited by 'min' and 'max' m/z values
    spectrum is either list, np.ndarray, or pandas.DataFrame 
    min and max are float
    """
    if isinstance(spectrum, np.ndarray):
        spectrum= pandas.DataFrame(spectrum)
        spectrum.columns = ['Mass','Intensity']
    if isinstance(spectrum, str):
        spectrum= pandas.read_table(StringIO(spectrum),delim_whitespace=True,header=None,names=['Mass','Intensity'])
    if isinstance(spectrum, pandas.DataFrame):
        spectrum.columns = ['Mass','Intensity']
    spectrum['Product']=spectrum.Mass*spectrum.Intensity
    spectrum=spectrum[spectrum.Mass>=min]
    spectrum=spectrum[spectrum.Mass<=max]
    a=spectrum.Product.mean()*charge
    b=spectrum.Intensity.mean()
    return a/b
 
def resample_spectrum(spectrum,low=0,high=10000000,rate=25,padding=1): 
    ''' Function resamples original spectrum to standardized rate.
    Input: numpy array spectrum containing 2 columns, left and right limits
    (low and high) and resumpling rate. Returns Pandas DataFrame new
    '''
    import pandas
    import numpy as np
    from scipy import interpolate
    # try:
    spectrum=pandas.DataFrame(spectrum)
    spectrum.columns = ['Mass','Intensity']
    # print(spectrum)
    # print('low',low)
    # print('high',high)

    if low<spectrum['Mass'].min():
        low=spectrum['Mass'].min()
    if low>=spectrum['Mass'].max():
        low=spectrum['Mass'].min()
    if high>spectrum['Mass'].max():
        high=spectrum['Mass'].max()
    if high<=spectrum['Mass'].min():
        high=spectrum['Mass'].max()
    if high<=low:
        low=spectrum['Mass'].min()
        high=spectrum['Mass'].max()
    # print("low,high,rate=",low,high,rate)
    smpl=int((high-low)*rate)
    spectrum=(spectrum[(spectrum['Mass'].values>= low-padding)])
    spectrum=(spectrum[(spectrum['Mass'].values <= high+padding)])
    # print(spectrum)
    # print('low',low)
    # print('high',high)
    flinear=interpolate.interp1d(spectrum['Mass'].values,spectrum['Intensity'].values)
    x=np.linspace(low,high,smpl+1,endpoint=True)
    y=flinear(x)
    new=pandas.DataFrame()
    new['Mass']=x
    new['Intensity']=y
    # print(new)
    return new
    # except:
        # return None

import subprocess
def run_win_cmd(cmd):
    result = []
    process = subprocess.Popen(cmd,
                               shell=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    for line in process.stdout:
        result.append(line)
    errcode = process.returncode
    for line in result:
        print(line)
    if errcode is not None:
        raise Exception('cmd %s failed, see above for details', cmd)

Ui_MainWindow, QMainWindow = loadUiType('CoMMon.ui')
###################################################UI##################################




###################################################UI##################################
class Main(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle('CoMMon')

        self.ui.pushButton_enter_kinetics_TB.clicked.connect(self._enter_kinetics_TB)
        self.ui.pushButton_enter_kinetics_ML.clicked.connect(self._enter_kinetics_ML)
        self.ui.pushButton_enter_kinetics_X.clicked.connect(self._enter_kinetics_X)
        self.ui.pushButton_get_cursor.clicked.connect(self._get_cursor)
        self.ui.pushButton_showDB.clicked.connect(self._show_DB)
        self.ui.pushButton_newDB.clicked.connect(self._create_newDB)
        self.ui.pushButton_input.clicked.connect(self._input)
        self.ui.pushButton_update.clicked.connect(self._update_without_settings)
        self.ui.pushButton_delete_entry.clicked.connect(self._delete_entry)
        self.ui.pushButton_show_entry.clicked.connect(self._show_entry)
        self.ui.pushButton_search_DB.clicked.connect(self._search_DB)
        self.ui.pushButton_paste.clicked.connect(self._paste)
        self.ui.pushButton_copy_original.clicked.connect(self._copy_original)
        self.ui.pushButton_transferDB.clicked.connect(self._transferDB)
        self.ui.pushButton_propagate_limits.clicked.connect(self._propagate_limits)
        self.ui.pushButton_centroid.clicked.connect(self._centroids)
        self.ui.pushButton_report.clicked.connect(self._report)
        self.ui.pushButton_show_plot.clicked.connect(self._plot_DB_spectrum)
        self.ui.pushButton_integrate.clicked.connect(self._integrate)

        self.w = QWidget()
        

    def _paste(self):  # paste clipboard to plainTextEdit_spectrum
        # import pyperclip
        # data = pyperclip.paste()
        # self.ui.plainTextEdit_spectrum.clear()
        # self.ui.plainTextEdit_spectrum.insertPlainText(data)

        clip=QApplication.clipboard().text()
        self.ui.plainTextEdit_spectrum.clear()
        self.ui.plainTextEdit_spectrum.insertPlainText(clip)

    def _copy_original(self):  # copy original spectrum from database to clipboard
        # import pyperclip
        # s = str(self.ui.plainTextEdit_spectrum.toPlainText())
        # pyperclip.copy(s)

        clip = str(self.ui.plainTextEdit_spectrum.toPlainText())
        QApplication.clipboard().setText(clip)
    def _update_without_settings(self):
        self._update(settings=False)

    def _update(self,settings=False):  # update entry in current database
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename.text()).strip()
        formulas = str(self.ui.plainTextEdit_formula.toPlainText())
        peaks = str(self.ui.plainTextEdit_annotations.toPlainText())
        spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        # Compress:
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = str(self.ui.plainTextEdit_ratios.toPlainText())
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        lig_mass = ''
        project= ''
        operator= ''
        created_date= ''
        type= ''
        polarity= ''
        trap= ''
        trans= ''
        conditions= ''
        lig_name= ''
        lig_mass= ''
        comment= ''
        lig_name =''
        annotations=''
        project=''
        # try:
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
        ls = c.fetchall()
        command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
            filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
        command = command+""" WHERE ID = '%s'""" % ID
        with conn:
            c.execute(command)
            c.execute(
                """UPDATE spectra SET spectrum=?,ratios=? WHERE ID=?""", (spectrum, ratios, ID))

        # if not self.ui.checkBox_cancel_messages.isChecked():
        # QMessageBox.about(self, "message", "Entry updated")
        # else:
        print("Entry updated")
        # except:
            # if not self.ui.checkBox_cancel_messages.isChecked():
                # QMessageBox.about(
                    # self, "warning", "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            # else:
            # print(
                    # "Cannot update entry that doesn't exist.Check if database with correct schema exists.")
            # return
        # finally:
        conn.close()

    def _show_DB(self, noshow=False):
        dir = 'DB'
        fi = os.listdir(dir)
        self.ui.plainTextEdit_search_result.clear()
        self.ui.plainTextEdit_search_result.insertPlainText(
            'Databases in DB folder:\n')
        S = ''
        for f in fi:
            if f[-2:] == 'db':
                S = S+f[:-3]+'\t'
        if noshow == False:
            self.ui.plainTextEdit_search_result.insertPlainText(S)
        return S.split()

        self.ui.plainTextEdit_search_result.clear()
        self.ui.plainTextEdit_INFO.clear()
        DBs = self._show_DB(noshow=True)
        # n1 = str(self.ui.comboBox_term_1.currentText())
        n1 = 'filename'
        n2 = str(self.ui.comboBox_term_2.currentText())
        b1 = str(self.ui.comboBox_bul1.currentText())
        b12 = str(self.ui.comboBox_bul1_2.currentText())
        date = str(self.ui.lineEdit_created_date.text()).strip('-')
        show1 = str(self.ui.comboBox_show_1.currentText()).strip()
        show2 = str(self.ui.comboBox_show_2.currentText()).strip()
        orderby = str(self.ui.comboBox_orderby.currentText())
        asdes = str(self.ui.comboBox_asdes.currentText())

        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n2))
        dt = ''
        if not n2 == '':
            sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
        else:
            sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                n1, m1, dt, orderby, asdes))
        for db in DBs:
            # try:
            fname = db
            id = ''
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            # try:
            S = ''
            c.execute(sql)
            ls = c.fetchall()
            if len(ls) > 0:
                s = 'DATABASE '+db+'\n'
                for f in ls:
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                    fn1 = c.fetchone()[0]
                    if not n2 == '':
                        c.execute(
                            """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                        fn2 = c.fetchone()[0]
                    sh1 = ''
                    sh2 = ''
                    if not show1 == '':
                        c.execute(
                            """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                        sh1 = c.fetchone()[0]
                    if not show2 == '':
                        c.execute(
                            """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                        sh2 = c.fetchone()[0]
                    id = id+str(f[0])+','

                    s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'
                S = S+s
                # print(S)
            self.ui.plainTextEdit_search_result.insertPlainText(S)
            self.ui.plainTextEdit_INFO.insertPlainText(S)
            # except Exception as e:
                # print(e)
            # finally:
                # conn.close()

    def _search_DB(self):  # database search engine
        self.ui.plainTextEdit_search_result.clear()
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            QMessageBox.about(
                    self, "warning", "Database {} doesn't exist".format(fname.upper()))
            return
        self.ui.lineEdit_DB_donor.clear()
        self.ui.lineEdit_DB_donor.setText(fname.upper())
        n1 = 'filename'
        n2 = ''
        b1 = ''
        b12 = ''
        show1 = 'filename'
        show2 = 'filename'
        orderby = str(self.ui.comboBox_orderby.currentText())
        asdes = str(self.ui.comboBox_asdes.currentText())
        dt = ''
        if n1 == 'comment':
            m1 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n1 == 'annotations':
            m1 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        else:
            m1 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n1))
        if n2 == 'comment':
            m2 = str(self.ui.plainTextEdit_comment.toPlainText())
        elif n2 == 'annotations':
            m2 = str(self.ui.plainTextEdit_annotations_2.toPlainText())
        elif n2 == '':
            m2 = ''
        else:
            m2 = eval('''str(self.ui.lineEdit_{}.text()).strip()'''.format(n2))
        s = ''
        id = ''
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            # try:
            if not n2 == '':
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} {} {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, b1, n2, b12, m2, dt, orderby, asdes))
            else:
                sql = ("""SELECT id FROM spectra WHERE {} LIKE '%{}%' {} ORDER by {} {}""".format(
                    n1, m1, dt, orderby, asdes))

            c.execute(sql)
            ls = c.fetchall()
            for f in ls:
                c.execute(
                    """SELECT {} FROM spectra WHERE ID = {}""".format(n1, f[0]))
                fn1 = c.fetchone()[0]
                if not n2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(n2, f[0]))
                    fn2 = c.fetchone()[0]
                sh1 = ''
                sh2 = ''
                if not show1 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show1, f[0]))
                    sh1 = c.fetchone()[0]
                if not show2 == '':
                    c.execute(
                        """SELECT {} FROM spectra WHERE ID = {}""".format(show2, f[0]))
                    sh2 = c.fetchone()[0]
                id = id+str(f[0])+','
                s = s+str(f[0])+'\t'+'\t'+str(sh1)+'\t'+str(sh2)+'\n'

            self.ui.plainTextEdit_search_result.insertPlainText(s)
            self.ui.plainTextEdit_INFO.clear()
            self.ui.plainTextEdit_INFO.insertPlainText(s)
            self.ui.plainTextEdit_search_result_ID_3.clear()
            self.ui.plainTextEdit_search_result_ID_3.insertPlainText(id[:-1])
        except Exception as e:
            print(e)
        finally:
            conn.close()

    def _show_entry(self):  # load entry from current database
        ID = str(self.ui.lineEdit_ID.text())
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
            ls = c.fetchall()
            filename = ls[0][1]
            self.ui.lineEdit_filename.clear()
            self.ui.lineEdit_filename.setText(str(filename).strip())
            project = ls[0][2]
            formulas = ls[0][7]
            self.ui.plainTextEdit_formula.clear()
            self.ui.plainTextEdit_formula.insertPlainText(str(formulas))
            peaks = ls[0][11]
            self.ui.plainTextEdit_annotations.clear()
            self.ui.plainTextEdit_annotations.insertPlainText(str(peaks))
            lig_name = ls[0][12]
            spectrum = ls[0][15]
            spectrum = cPickle.loads(zlib.decompress(spectrum))
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(spectrum)
            ratios = ls[0][16]
            ratios = cPickle.loads(zlib.decompress(ratios))
            self.ui.plainTextEdit_ratios.clear()
            self.ui.plainTextEdit_ratios.insertPlainText(str(ratios))

        except:
            print("Enry {} doesn't exist in the database {}".format(
                    ID, fname.upper()))
            return
        finally:
            conn.close()

    def _input(self):  # create new entry in current database
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return
        filename = str(self.ui.lineEdit_filename.text()).strip()
        formulas = str(self.ui.plainTextEdit_formula.toPlainText())
        peaks = str(self.ui.plainTextEdit_annotations.toPlainText())
        spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())
        ratios = str(self.ui.plainTextEdit_ratios.toPlainText())
        spectrum = sqlite3.Binary(zlib.compress(cPickle.dumps(spectrum)))
        ratios = sqlite3.Binary(zlib.compress(cPickle.dumps(ratios)))
        lig_mass = ''
        project= ''
        operator= ''
        created_date= ''
        type= ''
        polarity= ''
        trap= ''
        trans= ''
        conditions= ''
        lig_name= ''
        lig_mass= ''
        comment= ''
        lig_name =''
        annotations=''
        project=''
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        with conn:
            c.execute('SELECT max(rowid) FROM spectra')
            try:
                ID = c.fetchone()[0]+1
            except:
                ID = 1
            self.ui.lineEdit_ID.setText(str(ID))
            c.execute("SELECT * FROM spectra WHERE filename=:filename",
                      {'filename': filename})
            try:
                fn = c.fetchone()[1]
                QMessageBox.about(
                    self, "warning", "Item with file name {} already exists in the database. \nUse UPDATE to change it. ".format(fn))
            except:
                c.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                          'ID': ID, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum, 'ratios': ratios, 'annotations': annotations})
                # if not self.ui.checkBox_cancel_messages.isChecked():
                    # QMessageBox.about(
                        # self, "Message", "Entry added to database")
                # else:
                return

    def _delete_entry(self):  # delete entry in current database
        fname = str(self.ui.lineEdit_DB_file.text()).strip().upper()
        DBs = self._show_DB(noshow=True)
        if not fname in DBs:
            print("Database {} doesn't exist".format(fname.upper()))
            return

        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        ID = str(self.ui.lineEdit_ID.text())
        question = QMessageBox.question(self, 'Message', "Are you sure you want to delete entry # {}?".format(
                ID), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if question == 16384:
            with conn:
                c.execute("DELETE from spectra WHERE ID=:ID", {'ID': ID})

    def _create_newDB(self, fname='new'):  # create new database
        try:
            fname, ok = QInputDialog.getText(
                self, 'Input Dialog', 'Enter file name:')
            if os.path.exists('DB'):
                pass
            else:
                os.mkdir('DB')
            # if os.path.exists('DB/settings'):
                # pass
            # else:
                # os.mkdir('DB/settings')
        except:
            return
        self._newDB(fname=fname)

    def _newDB(self, fname='new'):  # create new database
        try:
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            with conn:
                c.execute("""CREATE TABLE spectra (ID INTEGER PRIMARY KEY,filename TEXT,project TEXT,operator TEXT,created_date TEXT,type TEXT,polarity TEXT,formulas TEXT,trap TEXT,trans TEXT,conditions TEXT,peaks TEXT,lig_name TEXT,lig_mass TEXT, comment TEXT, spectrum BLOB,ratios BLOB,annotations TEXT)""")
        except:
            QMessageBox.about(
                self, "confirm", "database DB/{}.db already exists".format(fname.upper()))
            return
        finally:
            conn.close()

    def _transferDB(self):
        '''transfer entries listed in plainTextEdit_search_result_ID_3 from donor to recipient database'''
        DBs = self._show_DB(noshow=True)
        donor = str(self.ui.lineEdit_DB_donor.text()).strip().upper()
        if not donor in DBs:
            print("Database {} doesn't exist".format(donor))
            return
        recipient = str(self.ui.lineEdit_DB_recipient.text()).strip().upper()
        if not recipient in DBs:
            self._newDB(fname=recipient)
        conn = sqlite3.connect("DB/{}.db".format(donor))
        c = conn.cursor()
        conn2 = sqlite3.connect("DB/{}.db".format(recipient))
        c2 = conn2.cursor()
        id = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
        id1 = []
        for i in id:
            if not i == '':
                id1.append(int(i))
        c2.execute('SELECT max(rowid) FROM spectra')
        id2 = c2.fetchone()[0]
        if id2 == None:
            id2 = 0
        n = id2
        print('max id=', n)
        for ID in id1:
            with conn:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                ls = c.fetchall()
            filename = ls[0][1]
            project = ls[0][2]
            operator = ls[0][3]
            created_date = ls[0][4]
            type = ls[0][5]
            polarity = ls[0][6]
            formulas = ls[0][7]
            trap = ls[0][8]
            trans = ls[0][9]
            conditions = ls[0][10]
            peaks = ls[0][11]
            lig_name = ls[0][12]
            lig_mass = ls[0][13]
            comment = ls[0][14]
            spectrum = ls[0][15]
            ratios = ls[0][16]
            annotations = ls[0][17]
            spectrum1 = spectrum
            ratios1 = ratios

            with conn2:
                try:
                    c2.execute(
                        "SELECT * FROM spectra WHERE filename=:filename", {'filename': filename})
                    ls = c2.fetchall()
                    date = ls[0][4]
                    if created_date > date:
                        command = """UPDATE spectra SET filename='{}',project='{}',operator='{}',created_date='{}',type='{}',polarity='{}',formulas='{}',trap='{}',trans='{}',conditions='{}',peaks='{}',lig_name='{}',lig_mass='{}',comment='{}',annotations='{}'""".format(
                            filename, project, operator, created_date, type, polarity, formulas, trap, trans, conditions, peaks, lig_name, lig_mass, comment, annotations)
                        command = command+""" WHERE filename = '%s'""" % filename
                    else:
                        print("Newer item with file name {} already exists in the recipient database. No change needed. ".format(
                            filename))
                except:
                    n = n+1
                    c2.execute("INSERT INTO spectra VALUES (:ID,:filename,:project,:operator,:created_date,:type,:polarity,:formulas,:trap,:trans,:conditions,:peaks,:lig_name,:lig_mass, :comment, :spectrum,:ratios,:annotations)", {
                               'ID': n, 'filename': filename, 'project': project, 'operator': operator, 'created_date': created_date, 'type': type, 'polarity': polarity, 'formulas': formulas, 'trap': trap, 'trans': trans, 'conditions': conditions, 'peaks': peaks, 'lig_name': lig_name, 'lig_mass': lig_mass, 'comment': comment, 'spectrum': spectrum1, 'ratios': ratios1, 'annotations': annotations})

    def _propagate_limits(self):  # update entry in current database
        try:
            NEW_CONTENT = str(self.ui.plainTextEdit_annotations.toPlainText())
            IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
            field = 'peaks'
            fname = str(self.ui.lineEdit_DB_file.text()).upper()
            conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
            c = conn.cursor()
            for ID in IDs:
                c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': ID})
                command = """UPDATE spectra SET {} ='{}'  WHERE ID = '{}'""".format(
                    field, NEW_CONTENT, ID)
                with conn:
                    c.execute(command)
        except:
            QMessageBox.about(
                self, "warning", "Operation failed. Check database.")

    def _integrate(self):
    
        # ID = str(self.ui.lineEdit_ID.text())
        # self._show_entry()
        spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())# spectrum is loaded as str
        spectrum = pandas.read_csv(StringIO(spectrum), delim_whitespace=True, names=[
                                     'Mass', 'Intensity'])  # spectrum is Pandas pandas.DataFrame
        limits = str(self.ui.plainTextEdit_annotations.toPlainText()).split('\n')
        rate = int(self.ui.lineEdit_rate_3.text())
        padding= int(self.ui.lineEdit_padding.text())
        
        centroid = ''
        area = ''
        Prod=0
        AR=0

        try:
            for f in enumerate(limits):
                if not len(f[1].split())==3:
                
                    print('f fail',f)
                    continue
                left = float(f[1].split()[1])
                right = float(f[1].split()[2])
                if self.ui.checkBox_chargeNormalize.isChecked():
                    ch=int(f[1].split()[0])
                else:
                    ch=1
                print(f)
                # print(ch,left,right)
                if self.ui.radioButton_resample.isChecked():
                    new = resample_spectrum(spectrum, left, right, rate,padding)
                    # print('spectrum',spectrum)
                    # print('new',new)
                else:
                    new = spectrum.copy()
                A=new.Intensity.sum()/ch
                area = area+str(round(A))+'\n'
                AR=AR+A
                COG = center_of_gravity(new, left, right,ch)
                Prod=Prod+COG*A
                
                COG = round(COG, 2)
                centroid = centroid+str(round(COG, 2))+'\n'
            cAVE=round(Prod/AR,2)
            if not self.ui.checkBox_average.isChecked():
                cAVE=''
            self.ui.plainTextEdit_ratios.clear()
            self.ui.plainTextEdit_ratios.insertPlainText(centroid+'\n'+str(cAVE))
            self.ui.plainTextEdit_formula.clear()
            self.ui.plainTextEdit_formula.insertPlainText(area)
        except Exception as e:
            QMessageBox.about(self, "warning", "Check if the spectrum exist. If you process high resolution spectrum increase sampling rate and padding ~10 fold. Check list of windows. Must contain 3 numbers")
            return

    def _centroids(self):
        # self.ui.checkBox_cancel_messages.setChecked(True)
        try:
            IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
            for ID in IDs:
                self.ui.lineEdit_ID.setText(ID)
                self._show_entry()
                spectrum = str(self.ui.plainTextEdit_spectrum.toPlainText())# spectrum is loaded as str
                self._integrate()
                
                self._update()      
        except Exception as e:
            QMessageBox.about(self, "warning", "Check ID entries in Manage Database tab. Check if the spectrum exist.Check ID entries in Manage Database tab. If you process high resolution spectrum increase sampling rate and padding ~10 fold (padding may require more than 10).")
            return

    def _report(self):  # report for centroids or areas
        IDs = str(self.ui.plainTextEdit_search_result_ID_3.toPlainText()).split(',')
        fname = str(self.ui.lineEdit_DB_file.text()).upper()
        conn = sqlite3.connect("DB/{}.db".format(fname.upper()))
        c = conn.cursor()
        DF = pandas.read_csv(StringIO(''), delim_whitespace=True,names=['file name'])
        for id in IDs:
            if not id == '':
                with conn:
                    c.execute("SELECT * FROM spectra WHERE ID=:ID", {'ID': id})
                ls = c.fetchall()
                file = ls[0][1]
                ratios = ls[0][16]
                conditions = ls[0][10]
                ratios = cPickle.loads(zlib.decompress(ratios))
                line = ratios
                df = pandas.read_csv(StringIO(line),delim_whitespace=True, names=[file])
                DF = pandas.concat([DF, df], axis=1)
        try:
            DF.T.to_csv('results/report4database_{}.csv'.format(fname.upper()), index=False)
        except:
            fname, ok = QInputDialog.getText(self, 'Input Dialog', 'Cannot save to file report4database_{}.csv. \nCheck if the file is opened in other program. Close it or enter a new file name:'.format(fname.upper()))
            DF.T.to_csv('results/{}.csv'.format(fname.upper()), index=False)

    def _plot_DB_spectrum(self):  # plot spectrum from plainTextEdit_spectrum field
        import matplotlib.pyplot as plt
        Spectrum = StringIO(str(self.ui.plainTextEdit_spectrum.toPlainText()))
        df = pandas.read_csv(Spectrum, delim_whitespace=True, names=[
                               'Mass', 'Intensity'])
        linewidth = 1.0
        fontsize = 12.0
        offset = [0,0.5]
        plt.rc('xtick', labelsize=fontsize)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=fontsize)    # fontsize of the tick labels


        fig = plt.figure()
        ax = fig.add_subplot(111)

        plt.plot(df.Mass, df.Intensity, color='blue',
                 linewidth=linewidth, label='spectrum')

        plt.xlabel('m/z')
        plt.ylabel('Intensity')
        plt.show()

    def _get_cursor(self): # obtain cursor position and show it in screen window
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \nconda install -c conda-forge pyautogui\nor\npip install pyautogui")    
        x,y=pyautogui.position()
        self.ui.cursor.setText(str(x)+','+str(y))
        width, height = pyautogui.size()
        self.ui.screen.setText('{}x{}'.format(width, height))

############### AUTOMATION ################################################
    def _enter_kinetics_X(self): #Process X-calibur chromatogram
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \nconda install -c conda-forge pyautogui\nor\npip install pyautogui")    
        fi=str(self.ui.kinetics_file.text()).strip()
        pyautogui.PAUSE = 1
        pyautogui.FAILSAFE = True
        period=int(self.ui.kinetics_period_2.text()) 
        numdata_2=int(self.ui.numdata_2.text()) 
        start_collection=float(self.ui.start_data_collection.text())
        delay=int(self.ui.delay_2.text()) 
        X_spectrum_coords=str(self.ui.X_spectrum_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        Xcoords=str(self.ui.Xcoords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        SWARMcoords=str(self.ui.SWARMcoords2.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        
        for f in range(numdata_2):
            self.ui.plainTextEdit_spectrum.clear()
            start=start_collection+f*period
            self.ui.lineEdit_filename.setText(fi+str(start))
            pyautogui.click(int(Xcoords[0]),int(Xcoords[1]), button='left')
            pyautogui.hotkey('alt', 'D')
            pyautogui.hotkey('R')
            pyautogui.hotkey('alt', 'T')
            pyautogui.typewrite('{}-{}'.format(str(start),str(start+period)))
            pyautogui.press('enter')
            time.sleep(delay)
            pyautogui.click(int(X_spectrum_coords[0]),int(X_spectrum_coords[1]), button='left')
            pyautogui.click(int(X_spectrum_coords[0]),int(X_spectrum_coords[1]), button='right')
            pyautogui.hotkey('E')
            pyautogui.press('enter')
            clip=QApplication.clipboard().text()
            time.sleep(1)
            pyautogui.click(int(SWARMcoords[0]),int(SWARMcoords[1]), button='left')
            clip = '\n'.join(clip.split('\n')[10:])
            self.ui.plainTextEdit_spectrum.insertPlainText(clip)
            time.sleep(1)
            self._input()
            time.sleep(1)

    def _enter_kinetics_ML(self): #Process WATERS MassLynx chromatogram
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \nconda install -c conda-forge pyautogui\nor\npip install pyautogui")    

        fi=str(self.ui.kinetics_file.text()).strip()
        pyautogui.PAUSE = 1
        pyautogui.FAILSAFE = True
        numscans=int(self.ui.numscans.text())
        period=int(self.ui.kinetics_period.text()) 
        numdata=int(self.ui.numdata.text()) 
        delay=int(self.ui.delay.text()) 
        chromatogram=str(self.ui.chromatogram.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        lynx=str(self.ui.lynx.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        SWARMcoords=str(self.ui.SWARMcoords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        
        for f in range(numdata):
            start=f*period*30
            self.ui.lineEdit_filename.setText(fi.strip()+str(start))
            pyautogui.click(int(chromatogram[0]),int(chromatogram[1]), button='left')
            pyautogui.hotkey('alt', 'p','c')
            if start==0:
                pyautogui.typewrite('{}:{}'.format(str(start+1),str(start+numscans)))
            else:
                pyautogui.typewrite('{}:{}'.format(str(start),str(start+numscans)))
            pyautogui.press('enter')
            time.sleep(delay)
            pyautogui.hotkey('alt', 'e','l')
            clip=QApplication.clipboard().text()
            time.sleep(1)
            pyautogui.hotkey('alt', 'f','x')
            pyautogui.click(int(SWARMcoords[0]),int(SWARMcoords[1]), button='left')
            self.ui.plainTextEdit_spectrum.insertPlainText(clip)
            time.sleep(1)
            self._input()
            time.sleep(1)

    def _enter_kinetics_TB(self): #Process WATERS MassLynx chromatogram
        import time
        try:
            import pyautogui   #requires pyautogui module
        except:
            QMessageBox.about(self, "warning","This feature requires pyautogui module. Try to install it with command \nconda install -c conda-forge pyautogui\nor\npip install pyautogui")    

        fi=str(self.ui.kinetics_file.text()).strip()
        pyautogui.PAUSE = 1
        pyautogui.FAILSAFE = True
        start_data_collection=int(self.ui.start_data_collection_3.text()) 
        period=int(self.ui.kinetics_period_4.text()) 
        delay=int(self.ui.delay_4.text()) 
        numdata=int(self.ui.numdata_4.text()) 
        
        
        TB_coords=str(self.ui.TB_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        RT_FROM_coords=str(self.ui.RT_FROM_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        RT_TO_coords=str(self.ui.RT_TO_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        PROCESS_coord=str(self.ui.PROCESS_coord.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        TB_spectrum_coords=str(self.ui.TB_spectrum_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        copy_data_coords=str(self.ui.copy_data_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        CoM_coords=str(self.ui.CoM_coords.text()).replace(',',' ').replace('(',' ').replace(')',' ').split()    
        
        for f in range(numdata):
            start=f*period
            end=start+period
            self.ui.lineEdit_filename.setText(fi.strip()+str(start))
            pyautogui.click(int(TB_coords[0]),int(TB_coords[1]), button='left')
            pyautogui.click(int(RT_FROM_coords[0]),int(RT_FROM_coords[1]), button='left')
            pyautogui.click(clicks=2)
            pyautogui.typewrite(str(start))
            pyautogui.press('enter')
            pyautogui.press('enter')
            pyautogui.click(int(RT_TO_coords[0]),int(RT_TO_coords[1]), button='left')
            pyautogui.click(clicks=2)
            pyautogui.typewrite(str(end))
            pyautogui.press('enter')
            pyautogui.press('enter')
            pyautogui.click(int(PROCESS_coord[0]),int(PROCESS_coord[1]), button='left')
            time.sleep(delay)
            pyautogui.click(int(TB_spectrum_coords[0]),int(TB_spectrum_coords[1]), button='right')
            pyautogui.click(int(copy_data_coords[0]),int(copy_data_coords[1]), button='left')
            pyautogui.click(int(CoM_coords[0]),int(CoM_coords[1]), button='left')
            # clip=QApplication.clipboard().text()
            # clip = '\n'.join(clip.split('\n')[1:])
            # self.ui.plainTextEdit_spectrum.insertPlainText(clip)
            self._paste()
            clip = str(self.ui.plainTextEdit_spectrum.toPlainText())
            time.sleep(1)
            clip = '\n'.join(clip.split('\n')[1:])
            self.ui.plainTextEdit_spectrum.clear()
            self.ui.plainTextEdit_spectrum.insertPlainText(clip)
            time.sleep(1)
            self._input()
            time.sleep(1)

    ##############################################################################
if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle(QStyleFactory.create("windows"))
    main = Main()
    main.show()
    sys.exit(app.exec_())
