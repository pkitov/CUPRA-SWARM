# from .decorators import timer
# @timer
def resample_spectrum(spectrum,low=0,high=10000000,rate=25,padding=1): 
    ''' Function resamples original spectrum to standardized rate.
    Input: numpy array spectrum containing 2 columns, left and right limits
    (low and high) and resumpling rate. Returns Pandas DataFrame new
    '''
    import pandas
    import numpy as np
    from scipy import interpolate
    # try:
    spectrum=pandas.DataFrame(spectrum)
    spectrum.columns = ['Mass','Intensity']
    # print(spectrum)
    # print('low',low)
    # print('high',high)

    if low<spectrum['Mass'].min():
        low=spectrum['Mass'].min()
    if low>=spectrum['Mass'].max():
        low=spectrum['Mass'].min()
    if high>spectrum['Mass'].max():
        high=spectrum['Mass'].max()
    if high<=spectrum['Mass'].min():
        high=spectrum['Mass'].max()
    if high<=low:
        low=spectrum['Mass'].min()
        high=spectrum['Mass'].max()
    # print("low,high,rate=",low,high,rate)
    smpl=int((high-low)*rate)
    spectrum=(spectrum[(spectrum['Mass'].values>= low-padding)])
    spectrum=(spectrum[(spectrum['Mass'].values <= high+padding)])
    # print(spectrum)
    # print('low',low)
    # print('high',high)
    flinear=interpolate.interp1d(spectrum['Mass'].values,spectrum['Intensity'].values)
    x=np.linspace(low,high,smpl+1,endpoint=True)
    y=flinear(x)
    new=pandas.DataFrame()
    new['Mass']=x
    new['Intensity']=y
    # print(new)
    return new
    # except:
        # return None
if __name__ == '__main__':
    import pandas
    import numpy as np
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    # new=resample_spectrum(df,low=0,high=100000,rate=25)
    new=resample_spectrum(df)
    x=new.Mass.values
    y=new.Intensity.values
    plt.plot(x,y,color='b')
    plt.show()
