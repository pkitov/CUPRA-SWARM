import pandas
import numpy as np
""" takes 2 spectra target and reference and subtract on from the other
    ref_spectrum and tag_spectrum are DataFrame or ndarrays each containing 2 columns
    refmz is m/z for peak used for alignement
    return: a DataFrame with smoothed and aligned spectra for tag and ref as well as difference
""" 
from .resample_spectrum import resample_spectrum
from .annotate import PeakID
from scipy.signal import savgol_filter as sg

def difference(ref_spectrum, tag_spectrum,refmz,delta,low, high,rate=25,sgwin=41,sgorder=4,doSG=0,scale=0):
    # DIFFERENCE=TARGET-REFERENCE
    newR=resample_spectrum(ref_spectrum.values,low, high,rate)
    newT=resample_spectrum(tag_spectrum.values,low, high,rate)
    DF=pandas.DataFrame()
    DF['Mass']=newR.Mass
    DF['ref']=newR.Intensity
    DF['tag']=newT.Intensity
    DF['SG_ref']=sg(DF['ref'].values,sgwin,sgorder)
    DF['SG_tag']=sg(DF['tag'].values,sgwin,sgorder)
    if doSG==1:
        DF=DF.drop(['ref','tag'], axis=1)
        dataR=DF.drop(['SG_tag'], axis=1)
        dataT=DF.drop(['SG_ref'], axis=1)
    else:
        DF=DF.drop(['SG_tag','SG_ref'], axis=1)
        dataR=DF.drop(['tag'], axis=1)
        dataT=DF.drop(['ref'], axis=1)
    DF.columns = ['Mass','ref','tag']
    peaks=dataR
    peaks.columns = ['Mass','Intensity']
    ar=PeakID(peaks,refmz,delta)
    CR=ar[0] #now this is corrected value for reference peak
    peaks=dataT
    peaks.columns = ['Mass','Intensity']
    at=PeakID(peaks,refmz,delta)
    CT=at[0] #now this is corrected value for reference peak
    DC=at[0]-ar[0]
    if scale==0: #scale using reference peak
        DF['ref']=DF['ref'].values/ar[1]
        DF['tag']=DF['tag'].values/at[1]
    else:
        scale=DF['ref'].sum()/DF['tag'].sum()
        DF['ref']=DF['ref'].values/scale
    DF['Dif'] = (DF.tag-DF.ref).values
    return DF
        
def test():
    print('no test yet')
if __name__ == '__main__':
    
    test()

