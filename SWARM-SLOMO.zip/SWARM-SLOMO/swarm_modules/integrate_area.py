import pandas
import numpy as np

try:
    from StringIO import StringIO # for Python 2.7
except ImportError:
    from io import StringIO # for Python 3.x

def center_of_gravity(spectrum,min,max):
    """This function calculate centroid of the area in spectrum limited by 'min' and 'max' m/z values
    spectrum is either list, np.ndarray, or pandas.DataFrame 
    min and max are float
    """
    if isinstance(spectrum, np.ndarray):
        spectrum= pandas.DataFrame(spectrum)
        spectrum.columns = ['Mass','Intensity']
    if isinstance(spectrum, str):
        spectrum= pandas.read_table(StringIO(spectrum),delim_whitespace=True,header=None,names=['Mass','Intensity'])
    if isinstance(spectrum, pandas.DataFrame):
        spectrum.columns = ['Mass','Intensity']
    spectrum['Product']=spectrum.Mass*spectrum.Intensity
    spectrum=spectrum[spectrum.Mass>min]
    spectrum=spectrum[spectrum.Mass<max]
    a=spectrum.Product.mean()
    b=spectrum.Intensity.mean()
    return a/b
    
    
def test():
    import matplotlib.pyplot as plt
    df=pandas.read_table('test_swarm_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    print(df)
    test=df.copy()
    min=2167
    max=2170
    center=center_of_gravity(test,min,max)
    # print(test)
    x=df.Mass.values
    y=df.Intensity.values
    from annotate import PeakID
    a,b,c=PeakID(df,center,1)
    # z=df[df.Mass==center].Intensity
    # print(center,a,b,c)
    plt.plot(x,y,color='b')
    plt.bar(center,b,color='r')
    plt.show()
if __name__ == '__main__':
    test()