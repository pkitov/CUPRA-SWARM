import pandas
import numpy as np
"""If performing test comment the following imports
""" 
from .resample_spectrum import resample_spectrum
from .baseline import baseline
from .annotate import PeakID

def adducts_removal(df,PEAKS,ref,MZ,refint,delta,window,each,lamE,pE,iter):
    """ This function performs SWARM cleaning of spectrum given in pandas.DataFrame or np.ndarray 'df'
    df must contain 2 columns 'Mass' and 'Intensity' (not nesessary these titles); 
    ref is a DataFrame and must contain 2 columns 'Mass' and 'Intensity' (not nesessary these titles); 
    PEAKS is a list of m/z (can be as strings), refmz and window must be float
    return: new DataFrame with SWARM-ed spectrum
    USAGE: ref distribution must be not rescaled according to charge state prior to imput
    
    """
    if isinstance(df, np.ndarray):
        df=pandas.DataFrame(df)
    df.columns = ['Mass','Intensity']
   
    for peak in PEAKS:
        peaks=pandas.DataFrame(df.values)
        peaks.columns = ['Mass','Intensity']
        MZ,INT,d=PeakID(peaks,float(peak),delta)
        peak=MZ #corrected value
        peak1int=INT # intensity of ref peak
        df['tmp']=ref.Intensity
        tmp1=(df[(peak<=df.Mass) & (df.Mass<=peak+window)])
        try:
            shift1=tmp1.index[0]-ref.index[0]
        except:
            # QMessageBox.about(self, "warning","Operation failed. Try to adjust spectrum range") 
            print("shift should have positive value: tmpl-ref=",tmp1.index[0]-ref.index[0])
        print(ref)
        print(shift1)
        df.tmp=(df.tmp.shift(shift1))
        f1=(peak1int)/(refint)
        # f1=(peak1int)/(refint)
        df.tmp=(df.tmp)*f1
        df['tmp'].fillna(0, inplace=True)
        df['Intensity']=df.Intensity-df.tmp
        df=df.drop(['tmp'], axis=1)
        if each==1:
            bsl=baseline(df.Intensity.values, lam=lamE, p=pE, niter=iter)
            df.Intensity=df.Intensity-bsl
    return df
def clean_adducts(Spectrum,Annt,refmz,delta,window,rate,each,lamE,pE,iter):
    """ This fuction prepares input for adducts_removal in case of different charge states in annotations 
    PERHAPS REDUNDANT 
    """
    A=Annt.drop(['Label','Delta','Charge'], axis=1)
    refmz,refint,y=PeakID(Spectrum,refmz,delta) # update refmz
    MZ,x,y=PeakID(Annt,refmz,delta)
    Annt=Annt.sort_values(by='Mass', ascending=True)
    chars=sorted(list(set(Annt.Charge.tolist())))
    print(chars)
    
    refcharge=int(Annt[Annt.Mass==MZ].Charge.values[0])
    if refcharge==0:
        refcharge=1
    ref=(Spectrum[(refmz<=Spectrum.Mass) & (Spectrum.Mass<=refmz+window)]) #cut a fragment containing FF linker peak
    for char in chars:
        PEAKS=Annt.Mass[Annt.Charge==char].tolist()
        ref1=DataFrame()
        if char==0:
            char=1
        ref1['Mass']=ref.Mass*refcharge/int(char)
        ref1['Intensity']=ref.Intensity
        ref1=resample_spectrum(ref1,ref['Mass'].min(),ref['Mass'].max(),rate)
        # print('ref.shape=',ref.shape)
        Spectrum=adducts_removal(Spectrum,PEAKS,ref1,ref1['Mass'].min(),ref1['Intensity'].max(),delta,window*refcharge/int(char),each,lamE,pE,iter)
    print(Spectrum)
    return Spectrum
def test():
    # refmz=2041.250
    # window=35
    # delta=1
    # each=1
    refmz=29581.5 #test for unidec
    window=210#test for unidec
    delta=1#test for unidec
    each=0
    # df=pandas.read_table('test_swarm_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    df=pandas.read_table('test_unidec_spectrum.txt', index_col=False, header=None, names=['Mass','Intensity'])
    df=resample_spectrum(df,df['Mass'].min(),df['Mass'].max(),25)
    df['Intensity']=sg(df['Intensity'].values,41,4)
    bsl=baseline(df.Intensity.values, lam=100000000, p=0.001, niter=10)
    df.Intensity=df.Intensity-bsl
    MZ,INT,d=PeakID(df,float(refmz),delta)
    ref=(df[(MZ<=df.Mass) & (df.Mass<=MZ+window)]) #cut a fragment containing FF linker peak
    # PEAKS=pandas.read_table('test_peaks.txt', index_col=False, header=None, names=['Mass','Intensity','a','b']).Mass.tolist()
    PEAKS=pandas.read_table('test_unidec_peaks.txt', index_col=False, header=None, names=['Mass','Intensity','a','b']).Mass.tolist()
    # print(ref)
    # print(df)
    #test for function adducts_removal 
    Spectrum=adducts_removal(df,PEAKS,ref,MZ,INT,delta=delta,window=window,each=each,lamE=1000000,pE=0.01,iter=10) 
    # window is not scaled since ref has the same charge as the peaks to be cleaned 
    # print(Spectrum) 
    x=Spectrum.Mass.values
    y=Spectrum.Intensity.values
    plt.plot(x,y,color='b')
    plt.show()
if __name__ == '__main__':
    from resample_spectrum import resample_spectrum
    from baseline import baseline
    from annotate import PeakID
    from scipy.signal import savgol_filter as sg
    import matplotlib.pyplot as plt

    test()

